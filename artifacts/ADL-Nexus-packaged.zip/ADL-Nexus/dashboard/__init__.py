"""Metrics and dashboard helpers."""
